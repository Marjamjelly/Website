# Thoughts

- Automata are cool
- Tiling is hard
- I like blinking text